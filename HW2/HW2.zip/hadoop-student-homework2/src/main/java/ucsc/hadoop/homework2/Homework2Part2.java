package ucsc.hadoop.homework2;

public class Homework2Part2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(Homework2Part2.class.getName());
	}

}
