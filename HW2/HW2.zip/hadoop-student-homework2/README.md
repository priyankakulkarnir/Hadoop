hadoop-student-homework
=======================

starting project for students to do homework